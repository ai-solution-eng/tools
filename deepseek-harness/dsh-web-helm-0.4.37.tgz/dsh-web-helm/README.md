# DeepSeek Harness Web — Multi-User on HPE Private Cloud AI

Deploy and manage multiple isolated [DeepSeek Harness (`dsh`)](https://github.com/deepseek-ai/deepseek-harness) coding-agent environments on **HPE Private Cloud AI**. Each user gets their own PVC-backed workspace, and a shared workspace enables team collaboration.

Port of the `opencode` chart (`opencode-web-helm`): same router, admin console, terminal, data manager and preview machinery — with the [`dsh web`](https://github.com/deepseek-ai/deepseek-harness) UI in place of opencode/OpenChamber. **OpenChamber is not used.**

Chart: `dsh-web-helm` · current version **0.4.22** (dsh `0.2.1-rc.2`, Node 22.23.3 image).
0.4.4 fixes the VAST quota-collision hang for long usernames: quota names are `csi:<ns>:<pvc>`
**truncated to 64 chars** — with a long namespace (e.g. `project-user-alejandro-morales-martinez`)
only the first ~20 chars of the PVC name survive, so a version *suffix* was invisible to VAST and
re-provisions collided with orphaned quotas ("Quota name must be unique per tenant") → workspace
PVC Pending forever. Per-user PVC names now embed the version **early**
(`dsh-<nameVersion>-<slug>-workspace-pvc`; deployment/service names unchanged) so every
nameVersion bump mints a distinct quota name; units converge via the `dsh-web-helm/claims`
annotation — old claims are left behind and can be label-deleted manually. Per-namespace shared
PVCs are also provisioned RWX now (matching the release-level shared PVC).
0.4.1 fixes a router crash-loop on the first platform (SSO) login: the provision-watch key
(namespace/name composite) leaked into the deployment-name position of the API path, producing a
malformed request whose rejection crashed the process; the watch now passes name and namespace
separately and never rejects (failures surface on the setup-status page instead).
0.4.2 makes unit cleanup orphan-proof: user deletion discovers unit namespaces via a
**cluster-wide anchor scan** (`dsh-anchor-<slug>`) in addition to the registry, and the uninstall
hook adds a **cluster-wide labeled discovery phase** — an uninstall now finds every namespace
hosting `dsh-user-managed=true` objects even when the registry entry is already gone (delete
safety unchanged: label-scoped deletes + the `ezprojects.hpe.com/*` skip-assert).
0.4.3 completes the router's platform ClusterRole: `delete` on configmaps (ownership anchors —
user deletion cascades the unit through them) and on pods (stale cleanup-job sweeper).

---

## Platform volumes for SSO users (0.4.0, study Option B)

With `platformIntegration.enabled: true` (on in `values-g2.yaml`), **SSO** users get their unit
deployed **inside their platform project namespace** (`project-user-<username>`) — the namespace
the EzProject operator created for them — with the platform volumes mounted **read-write**:

| Mount | Platform PVC | What it is |
|---|---|---|
| `/mnt/shared` | `kubeflow-shared-pvc` | **one cluster-wide shared filesystem** (every project namespace's PVC binds to the same VAST view); per-user directories live here |
| `/mnt/user` | `user-pvc` | the user's personal project volume (chowned by the platform to `<uid>:<gid>`) |

Local (non-SSO) users keep the classic single-namespace behavior; DSH's own `personal` / `shared` /
`state` volumes and Data Manager roots are unchanged for everyone.

**Identity = the platform's.** The router reads the project's unix attributes from the
`project-info` ConfigMap (`USER_INFO_UID/GID/USERNAME/GROUP/HOMEDIR`), the unit init chowns the
DSH-owned volumes to that identity (owner-mismatch-only, never the platform volumes), and the
service stack (dsh, data manager, ttyd terminals) execs under it via `setpriv`. Files written
from DSH on the platform volumes are therefore **byte-identical to notebook-written files**
(same uid/gid), and modification rights are exactly "wherever the user's platform privileges
allow" — enforced by the kernel, surfaced as clean errors in the UI.

**Data Manager:** SSO users additionally see **Platform Shared (Kubeflow)** and **Platform
Workspace (Kubeflow)** roots (conditional: hidden for local users and while the platform PVCs
are not `Bound`; a unit provisioned in the pending state is re-stamped automatically once they
are). `platformIntegration.readOnly: true` mounts them but keeps the UI read-only for the
platform roots (unix permissions stay the real enforcement).

**Provisioning semantics:** the unit is *born* in the project namespace (K8s objects cannot move
between namespaces) when the user has **no existing unit** — sticky semantics preserved, so an
upgrade never silently moves or resets existing units. A brand-new SSO user cold-starts once.

**Requirements (the admin conversation):**
1. **Cross-namespace RBAC** — enabling the flag renders a `ClusterRole` +
   `ClusterRoleBinding` for the router and cleanup service accounts (pods/PVCs/services/
   configmaps/deployments/jobs, read/manifest, plus PVC+configmap delete). Secrets, leases and
   VirtualServices stay release-namespace-only. This is a real security grant — have the
   platform admins sign off (study §7.7).
2. **SSO host registration** at the platform auth layer (out-of-band, as before).

**Uninstall contract (enforced, study §7.6):** `helm uninstall` deletes only DSH-created objects
in the release namespace **and** each unit namespace from the registry — label-scoped
(`dsh-user-managed=true`), GC-cascaded through per-user **anchor** ConfigMaps
(`dsh-anchor-<slug>`) in the project namespaces, with a skip-assert that refuses any PVC carrying
an `ezprojects.hpe.com/*` label. **The platform PVCs are never deleted**; namespaces are never
deleted. Unit ConfigMap mirrors (the pod template mounts them cross-namespace via mirrored
copies) are DSH-owned and cleaned with the unit.

**PVC-survival contract (since 0.4.13, `storage.keepPvcOnDelete: true`):** user data PVCs —
per-user `dsh-*-ws-*/-st-*` claims and the
per-namespace `dsh-web-helm-shared-pvc` mirror — are never deleted by the app: not via the
anchor GC cascade (PVCs are no longer owner-referenced), not by the admin user-delete flow,
not by uninstall (the hook lists them and keeps them). The release shared PVC carries
`helm.sh/resource-policy: keep` and survives uninstall too. The first re-login / re-install
re-binds the exact same volumes, data intact. Deliberate purge = manual
`kubectl delete pvc -n <ns> <claim>`. Set `storage.keepPvcOnDelete: false` to restore the
legacy delete-on-uninstall behavior.

**Existing-install migration (run once after upgrading to ≥ 0.4.13):**
`scripts/strip-pvc-owner-refs.sh` removes the legacy anchor `ownerReferences` from all
`dsh-user-managed=true` PVCs; without it, pre-existing PVCs would still be GC-cascaded by
anchor deletion.

---

## Install (from-scratch, lessons baked in)

```bash
# 0. BEFORE choosing the endpoint: make sure no other VirtualService claims
#    the host. A duplicate host hijacks routing and shows the browser
#    "403 RBAC: access denied" (this bit us on g2 — "dsh." was claimed by
#    another tenant's 'deepseek-harness' VS).
kubectl get virtualservice -A -o yaml | grep -c "<your-host>."    # expect 0 (or 1 = yours)

# 1. Namespace — MUST NOT inject Istio sidecars. The router talks to the
#    K8s API directly; a sidecar makes namespace AuthorizationPolicies
#    enforce on the gateway→router hop → "403 RBAC: access denied".
kubectl create namespace dsh-web-helm
kubectl label ns dsh-web-helm istio-injection=disabled --overwrite

# 2. Deploy (dshEnv in values seeds $DSH_HOME/.env with CHANGEME keys;
#    edit them after first login via Data Manager → DSH Home → .env)
helm upgrade --install dsh-web-helm ./dsh-web-helm-0.2.0.tgz -n dsh-web-helm -f values-g2.yaml

# 3. Self-check
helm test dsh-web-helm -n dsh-web-helm

# 4. DNS: <endpoint host> → the ingressgateway LB IP
# 5. Log in at https://<host>/ → create users at /__dsh_admin (admin creds in values)
# 6. Replace CHANGEME keys: Data Manager → DSH Home → .env (hot-reloaded)
```

---

## Access & Authentication

Entry: `https://<endpoint>` (values: `ezua.virtualService.endpoint`; per-env hosts like `dsh-web.${DOMAIN_NAME}`).

| Purpose | URL |
|---|---|
| Login / account | `https://<host>/` |
| Admin console | `https://<host>/__dsh_admin` |
| Personal environment | `https://<host>/{username}` |
| Terminal | `.../{username}/terminal` (ttyd + tmux, tabbed/persistent) |
| Data Manager | `.../{username}/data-manager` (renamed from `/data_manager` in 0.4.14 — the underscore path is still served, aliased in-app) |
| Preview for port `PORT` | `.../{username}/__preview/{PORT}/` |

Since chart **0.3.5** the per-user URL prefix is the sanitized **username** itself (e.g. `/francesco-caliva/`) — usernames are unique in the registry, so the name is a safe identifier. Pre-0.3.5 links of the form `.../u-{12-hex-slug}/...` keep working (legacy bookmark route).

**Local accounts** are admin-provisioned only (self-registration hidden). **Platform SSO is optional** — `ezua.authorizationPolicy.enabled: false` (as in values-g2) deploys no AuthorizationPolicy and the app is gated by the router's own login. With SSO on (`true`), the host must also be registered with the platform auth layer (as opencode's host is) — that registration lives outside Helm.

### How dsh web is exposed (the token bridge)

`dsh web` binds loopback-only (the CLI refuses `--host 0.0.0.0`) and protects `/api` with a Host/Origin fence (`--trusted-host`) plus a per-process **launch token** exchanged for a cookie at `/?token=…`. The chart preserves that model fully:

```
browser ──https──> ezaf-gateway ──> router :8080 ──> pod nginx :8082 ──> dsh web 127.0.0.1:3080
```

1. The supervisor starts `dsh web --no-open --port 3080 --trusted-host <hosts>` and captures the printed `?token=` URL into the state volume.
2. In-pod nginx (:8082) validates the platform session (`auth_request` → auth validator :7684) and preserves the public `Host` header (dsh's fence).
3. First visit without a dsh cookie: dsh's 401 → nginx `error_page` → `@dsh_boot` → `/__dsh_boot` → validator 302s to `/?token=…` (relative!) → dsh sets its own cookie → clean `/`. The token never leaves the pod.
4. The router passes `/?token=…` through to the pod (it is dsh's exchange path — the router's login-page exemption on `/` does not swallow it).

Ports map: **443→8080 router→8082 nginx→3080 dsh** (loopback), 7681 ttyd, 7682 data manager, 7683 terminal manager, 7684 auth validator; `PREVIEW_EXCLUDE_PORTS` covers all of them.

---

## Configuration (patch, env)

| Field | What it defines |
|---|---|
| `dshCordisPatch` | the web profile's `cordis.patch.yml` (MCP integrations etc.), seeded base64, seed-once, watched + YAML-validated |
| `dshEnv` | Seed `.env` written into `$DSH_HOME` on first start — the credential layer (`apiKeyEnv` resolves from it; edit via Data Manager, hot-reloaded) |
| `dsh.version` / `dsh.port` | dsh npm version / loopback port (3080) |
| `nginx.clientMaxBodySize` | max request body the in-pod nginx accepts (default `64m`). nginx's own default is **1 MB**, which rejects a pasted/dropped image with **HTTP 413** once the browser base64-encodes it into a `/api/session/prompt` body — the request never reaches dsh. Raise it if users paste very large images. The platform gateway in front of the pod may impose its own, separate limit. |
| `dataManager.clientMaxBodySize` | nginx body cap for the `/data-manager` locations only (default `2g`). The `http{}`-level `nginx.clientMaxBodySize` stays as the UI cap (pasted images); raise both if users need bigger single files. |
| `dataManager.maxUploadMb` | server-side per-file guard (`DATA_MANAGER_MAX_UPLOAD_MB`, default `2048`). Keep it at or above `dataManager.clientMaxBodySize` so nginx stays the binding limit and an oversized file fails before it is streamed. |

**Hot reload:** the supervisor watches `settings.yaml`, `.env`, `profiles/web/cordis.patch.yml` and `profiles/web/dsh.profile` as FILES and restarts dsh on change — every changed YAML file is validated (js-yaml from the dsh install, `!!js`-aware) before the restart, so a broken edit can never crash-loop dsh. dsh also re-reads settings per request, so most model edits apply without restart. Edit via the Data Manager's **DSH Home** root or the terminal; seeded on first start only, never overwritten.

**AGENTS.md / skills:** no longer seeded by the chart (the `dshInstructions`/`dshSkills` values were removed). dsh still auto-loads a user-placed `/workspace/personal/AGENTS.md`, and skills dropped into `$DSH_HOME/skills/` hot-refresh natively.

**MLIS providers** (default seed): `llm-pi-ai.providers.*` with `api: openai-completions`, `compat.supportsDeveloperRole: false`, `maxTokensField: max_tokens`, and for DeepSeek-V4-style thinking models `compat.thinkingFormat: deepseek` + `reasoningEfforts`. Keys via `apiKeyEnv` → Secret.

**Telemetry:** dsh ships session-log upload and OTel **on by default**; the seed settings disable both (`session-log-deepseek.enabled: false`, telemetry `DISABLED`). Keep off for PCAI.

---

## Workspaces & Data Manager

| Mount | Type | Purpose |
|---|---|---|
| `/workspace/personal` | RWO PVC | Private workspace; dsh's default workspace root |
| `/workspace/shared` | RWX PVC | Team area (seeded from `shared/` with toy demos + venv) |
| `/var/dsh` (state PVC) | RWO PVC | `$DSH_HOME`, npm prefix, ttyd binary, boot state |

Data Manager roots: **Personal**, **Shared**, **DSH Home** (`$DSH_HOME` — settings.yaml, skills, sessions), State (non-navigable); SSO units with `platformIntegration.enabled` also get **Platform Shared** (`/mnt/shared`) and **Platform Workspace** (`/mnt/user`). Monaco editor, upload/download/zip, storage panel — path-traversal clamped to the navigable roots.

**Previews (0.4.37).** Double-clicking a file previews it in the dialog: images, PDF (native viewer, Range seeks), audio and video render inline, and **markdown and HTML now render too** — everything else still opens as text in Monaco. `.md` is rendered server-side by `/api/preview`: escape-first, zero dependencies, and **no raw-HTML passthrough** (a `<script>` in a .md file is displayed as text, never executed), with GFM tables, task lists, nested lists, fenced code and relative links/images resolved against the file's own folder. `.html` is served **verbatim** so an exported report keeps its own markup, but under `Content-Security-Policy: sandbox` — opaque origin, scripts cannot run, nothing remote may load — inside an iframe that also carries `sandbox=""`. Both are read-only previews; a **Source / Rendered** toggle in the dialog switches to the editor when the file needs changing. Nothing about this path can execute file content in the data-manager origin: markdown is escaped before parsing, and HTML is isolated twice over. Remote (https) images always render; a README's *local* sibling images are rewritten to the inline byte endpoint and may still be blocked by the sandbox in some browsers — use Download for those. One residual by design: because remote images are allowed, a hostile .md can still point an image at an external https URL and signal "someone opened this" to that host — no script runs and no file data is reachable; HTML previews block remote loads entirely.

**Uploads (0.4.30).** *Upload* takes plain files **and** compressed archives (.zip, .tar, .tar.gz/`.tgz`, .tar.xz, .tar.zst) — an archive is unpacked server-side unless you untick *Extract archives*, which is also the fastest way to land a big tree and the only path that preserves empty folders on every browser; *Upload folder* (`webkitdirectory`) keeps a directory tree as-is. Drag & drop accepts files **and** folders (entries API; empty folders preserved). Each file is one streamed request (temp file + `rename`, 3 in flight) with a progress dialog, per-file errors, cancel and retry. The pre-flight dialog sets the conflict policy (keep both / skip / overwrite), the permission policy (644/664/755/775) and hidden/temporary-entry skipping (`.git`, `.venv`, `~$…` Office lock files, `Thumbs.db` — on by default). Per-file ceiling: `dataManager.clientMaxBodySize` (default `2g`, per-location nginx override); `dataManager.maxUploadMb` is the server-side guard and must stay at or above it. The legacy whole-batch multipart endpoint is kept for browsers holding a cached SPA copy and is capped at 64 MiB.

---

## Baked user image (0.4.7)

User pods previously ran vanilla `node:22-bookworm-slim` and installed everything at boot (apt toolchain, `@deepseek-ai/dsh`, uv, ttyd — several minutes per pod, and the two apt stages re-ran on EVERY restart because apt state lives in the container layer, not on the PVCs). `images.user`/`images.init` now point at a **baked image** (`ghcr.io/ai-solution-eng/deepseek-harness:<tag>`) that carries the whole toolchain under `/opt/dsh` — fresh pods reach Ready in seconds.

Design contract (see `docker/user/Dockerfile`):

- Baked artifacts live under **`/opt/dsh`** (`/opt/dsh/npm`, `/opt/dsh/bin`) — never under `/var/dsh`, which the state PVC mounts and would shadow. The init container aliases the PVC paths (`/var/dsh/data/npm`, `/var/dsh/bin/{uv,uvx,ttyd}`) to the baked copies with guarded symlinks; `dsh-startup.sh` is unchanged.
- **Every runtime install step remains as a guarded fallback.** On the baked image the guards no-op; set `images.user/init` back to `node:22-bookworm-slim` (or bump `dsh.version` without rebuilding) and the old install-on-boot behavior resumes.
- The image tag is folded into `user-template-version`, so a `helm upgrade` with a new tag re-stamps all existing units (dedicated) onto the new image automatically.
- User pods pull with `IfNotPresent` — use immutable tags (no `latest`). If the registry package is private, set `images.pullSecret` to an imagePullSecret in the release namespace (public ghcr.io packages pull anonymously).

Build & push (single source of truth: the script reads `dsh.version` + `provisioning.aptPackages` from the values file; the image tag defaults to `dsh.version` — a version bump and an image rebuild stay coupled):

```sh
docker buildx build --platform linux/amd64 \
  -t ghcr.io/ai-solution-eng/deepseek-harness:0.1.7-rc.2 --push docker/user
# or simply: scripts/build-user-image.sh --push
```

Then `helm upgrade` (the values files already point at the matching tag).

---

## Docker in Docker (0.4.17)

**Docker is an SSO-identity capability** (security decision 2026-10-03: the classic login is a *shared* credential and daemon access is node-root-equivalent, so units resolved by a local session never get a daemon). SSO units get full `docker` power — build, run, tag, **push** — with no cluster-wide docker socket and no host mounts:

- **SSO + platform namespace (`project-user-*`, the default SSO path):** the daemon runs in a **per-user broker pod** in the release namespace (below); the unit's `dsh-web` container gets `DOCKER_HOST=tcp://dsh-dind-<user>-svc.<release-ns>.svc.cluster.local:2375` and the baked **docker CLI + buildx plugin**.
- **SSO + release-namespace fallback unit** (no platform project yet): the daemon is an **in-pod sidecar** on a loopback-only listener (`DOCKER_HOST=tcp://127.0.0.1:2375`) — reachable solely through the authenticated session.
- **Local (non-SSO) units: no daemon** — the CLI is present but `docker` reports "Cannot connect to the Docker daemon". Deliberate, not a bug.
- Its `/var/lib/docker` is **node-local `emptyDir`**: overlay2 layer extraction fails on VAST network volumes, so the image store is ephemeral — **push after building** (or `docker save` to the workspace).
- The daemon is not a shared socket: the in-pod sidecar is private to the unit's network namespace; the broker is private to the owning user's unit via the per-user NetworkPolicy.

### Proxied clusters (g2)

The router forwards `proxy.env` to the daemon (pulls/pushes go through `hpeproxy`) and mounts the `certificatesPolicy` CA bundle with `SSL_CERT_FILE`, so the Go daemon trusts the corporate MITM TLS for `ghcr.io`/Docker Hub. **Build** `RUN` steps need two extra adjustments (both proven necessary on g2 via the clearwing + container-builder-mcp work) — use the baked wrapper instead of raw `docker build`:

```sh
cd /workspace/personal/my-app

# RECOMMENDED: proxy-aware wrapper (adds --network host + explicit proxy
# build-args only when a proxy is configured; plain passthrough otherwise)
dockerbuild --platform linux/amd64 -t ghcr.io/<org>/my-app:0.0.1 --push .

# Raw equivalent (proxy env assumed set in your shell):
docker buildx build --platform linux/amd64 --network host \
  --build-arg HTTP_PROXY="$HTTP_PROXY" --build-arg HTTPS_PROXY="$HTTPS_PROXY" \
  --build-arg NO_PROXY="$NO_PROXY" \
  -t ghcr.io/<org>/my-app:0.0.1 --push .
```

Why: the daemon's default bridge network cannot reach `hpeproxy` (builds fail with connection errors), and Docker's *implicit* proxy build-arg forwarding does not reach the `RUN` steps' environment inside DinD — explicit `--build-arg`s do. `--network host` shares the pod network, where the proxy is reachable. `NO_PROXY` must contain `127.0.0.1` (the g2 values already do) so the CLI never proxies its own dial to the daemon.

Pushing to a private registry needs credentials (pods ship none):

```sh
echo "$GHCR_TOKEN" | docker login ghcr.io -u <username> --password-stdin
dockerbuild -t ghcr.io/<org>/my-app:0.0.1 --push .   # build + push in one shot
```

### Caveats

- **Bind mounts don't cross the DinD boundary**: `docker run -v /workspace/x:/x ...` resolves paths inside the *sidecar's* filesystem, not your PVC — the classic DinD limitation. Build contexts are fine (the CLI streams them to the daemon over the API).
- Built images are ephemeral (node-local emptyDir, **disk-capped via values `docker.diskSize`, 50Gi by default** — rendered as both the volume `sizeLimit` and the daemon container's `ephemeral-storage` limit, since the pairing is what makes the cap enforceable; exceeding it evicts the daemon's pod and the build fails with `no space left on device`, never node DiskPressure; `docker.diskRequest` tunes the scheduler reservation). **The blast radius depends on where the daemon runs**: broker mode (SSO/platform units) — only the *broker* pod is evicted and its Deployment restarts it with a fresh store; the user's session stays up. In-pod sidecar mode (classic units) — the eviction restarts the *user's* pod (the session dies with it). Either way, builds/pulls can never grow past the cap or put pressure on the node. Check usage with `docker system df`, reclaim with `docker system prune`; everything is re-pulled/re-built after a reschedule, and a `docker build` cache is likewise lost.
- Each running build/container consumes the pod's resources — the sidecar requests 250m/512Mi with 4 CPU / 8Gi limits (values `docker.resources`).
- **Platform units (`project-user-*`, SSO) get their daemon OUT-OF-POD (default).** The platform Kyverno policies deny privileged containers in user namespaces (observed on tr7: `ezprojects-restrict-privileged-pods` — an in-pod sidecar there makes the unit's Deployment POST fail with 400 and **breaks platform SSO entirely**). So the router deploys a **per-user broker** — one privileged `dsh-dind-<user>` Deployment + Service + NetworkPolicy (ingress restricted to the owning unit's pod) in the **release namespace**, where privileged is admitted — and the unit's terminal reaches it via `DOCKER_HOST=tcp://dsh-dind-<user>-svc.<release-ns>.svc.cluster.local:2375`. Same docker UX, no policy change needed. `docker.brokerForPlatformUnits: false` disables it (platform units then have no docker); `docker.onPlatformUnits: true` moves the daemon INTO the platform pod (loopback) — only after the platform team applies the Kyverno `PolicyException` (`dsh-user-managed=true`, kinds Deployment+Pod, policy `ezprojects-restrict-privileged-pods`).
- **Broker lifecycle:** created on the unit's first SSO resolve and converged on image/values changes (the `dsh-web-helm/dind-template-version` annotation), deleted on user delete, swept by the helm-uninstall hook (`dsh-user-managed=true`). Sizing reuses `docker.resources` / `docker.diskSize`.
- **Broker security note:** the docker API on 2375 is **unauthenticated** — the NetworkPolicy scopes dialing to the owning unit's pod; on clusters whose CNI ignores NetworkPolicy the exposure widens to the whole cluster (keep `brokerForPlatformUnits: false` there).
- Enable/disable per environment with values `docker.enabled` (requires the cluster to admit privileged containers; off by default in the HT/devday values).

Ready-made `PolicyException` for the platform team (one per `project-user-*` namespace; the two `any:` entries are ORed — dsh units carry `dsh-user-managed`, opencode units `opencode-user-managed`, never both):

```yaml
apiVersion: kyverno.io/v2
kind: PolicyException
metadata:
  name: dsh-opencode-dind-privileged
  namespace: project-user-<name>
spec:
  background: true
  exceptions:
    - policyName: ezprojects-restrict-privileged-pods
      ruleNames:
        - autogen-restrict-privileged-pods-user-namespace
        - restrict-privileged-pods-user-namespace
  match:
    any:
      - resources:
          kinds: [Pod, Deployment]
          selector:
            matchLabels:
              dsh-user-managed: "true"
      - resources:
          kinds: [Pod, Deployment]
          selector:
            matchLabels:
              opencode-user-managed: "true"
```

---

## Login lands inside the unit (0.4.8)

The first login after logout used to strand the user on the login menu ("Signed in as … / Open your environment") even though the session was already live: the in-pod validator's boot flow bounced the browser through `/?token=…` on the **main host**, where dsh's own post-exchange redirect to `/` hit the router's menu. The validator now performs the launch-token exchange **server-side** (the same fetch its readiness probe already used), captures dsh's session cookie, and 302s straight into `/<slug>/` — the entire boot flow stays inside the unit. SSO and local logins are now single-click (including through the provisioning loading screen). Validate locally with `scripts/test-boot-exchange.sh`.

---

## Troubleshooting (each line cost us a debugging session)

| Symptom | Cause | Fix |
|---|---|---|
| SSO user lands in `dsh-web-helm` (no platform volumes) | platform namespace missing, PVCs not `Bound`, or cross-ns RBAC not yet applied | check `project-user-<name>` exists + `project-info` ConfigMap; verify the ClusterRoles (`dsh-web-helm-router-platform`); the 60s context cache then provisions/adopts the platform unit on the next resolve |
| Data Manager shows no Platform roots for an SSO user | unit provisioned before the platform PVCs were Bound (mode `pending`), or `platformIntegration.enabled: false` | the router re-stamps the unit once the PVCs are Bound (check the `dsh-web-helm/platform-mounts` annotation); local users never see them by design |
| Router logs `[platform] context fetch failed … 403` | ClusterRole not applied (feature enabled but RBAC missing) | re-run `helm upgrade` so the gated ClusterRole renders; units keep working in the release namespace meanwhile |
| **Uninstall deleted nothing in a `project-user-*` ns** | registry unreadable during cleanup (secret gone/renamed) | cleanup falls back to the release namespace only; delete leftover `dsh-user-*`/`dsh-anchor-*` objects manually (platform PVCs are intentionally untouched) |
| Browser: **403 "RBAC: access denied"** (after SSO login) | ① Router pod has an Istio sidecar → namespace policies enforce on it; ② another VirtualService claims your host (routing hijack) | ① `kubectl label ns <ns> istio-injection=disabled` + restart router; ② `kubectl get virtualservice -A -o yaml \| grep <host>` → pick an unclaimed host |
| Browser: **500 nginx** on main page | nginx named location missing (`@dsh_boot`) | chart ≥0.1.2 |
| Redirect lands on **`:8082`** or **`127.0.0.1:3080`** | nginx `absolute_redirect` expands relative Locations with its listen port; validator passed dsh's loopback URL verbatim | chart ≥0.1.2 (`absolute_redirect off; port_in_redirect off`) and relative token redirect |
| **`/__dsh_boot → 503`** forever | `dsh-auth` container couldn't read the supervisor's boot-state file (no shared mount) | chart ≥0.1.4 (`state` mount, read-only) |
| **502 Bad Gateway** on main page right after claim | dsh web still booting (~60–90s) while nginx is already up | chart ≥0.1.5/0.1.7: readiness probes dsh's root via nginx `/healthz`; also just wait and reload |
| Login page shows at **`/?token=…`** | Router's `/` login-page reservation swallowed dsh's token exchange | chart ≥0.1.6 (`isDshTokenExchange` passthrough) |
| **settings.yaml edits never picked up** | Supervisor's JSON validator rejected YAML | chart ≥0.1.8 (YAML-aware watcher; dsh also re-reads settings per request) |
| Units **stuck NotReady** after 0.1.5 | Readiness probed dsh's nonexistent `/healthz` route | chart ≥0.1.7 (probe hits dsh root — 302 counts as ready); immediate unblock: revert readinessProbe to `tcpSocket 8082` |
| PVCs hang Pending / VAST quota collisions | VAST CSI 64-char quota-name truncation | `scripts/cleanup-dsh-web-helm-stale-quotas.sh` (dry-run by default) |

**Convergence:** per-user runtime changes roll automatically — the router stamps `dsh-web-helm/user-template-version` (RUNTIME_REV + dsh version + user image tag) and re-templates units whose annotation differs. **`RUNTIME_REV` is operator-tunable** (`values.yaml` / EzAppConfig values blob): bump it to force every unit to re-stamp onto the current template without editing the chart. Defaults to the shipped value (43), so leaving it unset changes nothing. If ever needed: `kubectl -n <ns> rollout restart deploy -l dsh-user-managed=true`.

---

## Key files in the user environment

| Path | Purpose |
|---|---|
| `/var/dsh/home/.dsh/settings.yaml` | dsh config (editable, hot-reloaded) |
| `/var/dsh/home/.dsh/profiles/web/cordis.patch.yml` | Profile patch layer (from `dshCordisPatch`, watched + validated) |
| `/var/dsh/home/.dsh/skills/` | Skills (user-managed; dsh hot-refreshes natively) |
| `/workspace/personal/AGENTS.md` | Agent instructions (user-managed; auto-loaded when present — no longer chart-seeded) |
| `/workspace/create-server.sh` | Preview server launcher |

## Scripts

- `scripts/verify-dsh-patches.sh` — **run this before every dsh version bump**: re-checks the
  image's guarded source patches (the `isLoopback` multi-user patch) and the Node floor
  (`commander@15` needs >= 22.12) against the published npm tarballs, in seconds, so an
  upstream file reorganisation fails here instead of 145s into `build-user-image.sh`
- `scripts/build-user-image.sh` — build/push the baked user image (reads `dsh.version` + `provisioning.aptPackages` from the values file)
- `scripts/show-current-config.sh` — print the **latest** `cordis.patch.yml` as rendered from `values.yaml` (read from the `<release>-project-config` ConfigMap; read-only, no pod needed). Handy for sending the current patch to the team.
- `scripts/push_dsh_cordis_patch.sh` — **stage** the web profile's patch layer into user envs without touching the live patch. Prefer `--from-configmap` (reads that same ConfigMap); `--from-cluster` remains as a fallback for clusters still on a chart that predates it.
  - **Staged, not applied:** the push lands as `profiles/web/cordis.patch-update.yml` beside the live `cordis.patch.yml`, which is never written. The sibling is inert — dsh loads the patch by fixed filename (not a glob) and the supervisor watches an explicit file list — so nothing reloads and no restart fires. Promote by moving it over the live name (the script prints the exact per-unit command). `TARGET_NAME=cordis.patch.yml` restores the old overwrite behaviour.
  - **Source:** `--from-cluster` takes the patch the chart already rendered into a unit's `init-dsh-storage` init container (the `dshCordisPatch` value baked in as base64), so `helm upgrade` → `--from-cluster` needs no local file. `--file PATH` pushes a local copy instead. Note there is **no** `cordis.patch.yml` in the repo and no ConfigMap for it — the chart seeds it into the deployment spec.
  - **Scope:** `--user <id>` (repeatable / comma-separated) targets specific users — the safe way to try a patch on yourself first; `--list-users` prints the IDs to pass. With no `--user` it targets every user unit (the default), and an ID that matches nothing exits 1 rather than silently pushing to all. Docker-in-Docker broker deployments share the `dsh-user-managed=true` label but are not dsh units, so they are skipped.
  - **Where your unit lives:** platform (Option B) users have their unit in `project-user-<slug>`, not the release namespace — pass `--namespace project-user-<slug>`.
- `scripts/user_manager.ipynb` — bulk user admin against the router API
- `scripts/pre-upgrade-check.sh` — preflight/record/verify around an upgrade. Asserts `KEEP_PVC_ON_DELETE=true` (a blocker if not — that setting is what stops an uninstall deleting user PVCs), reports the live `storage.nameVersion` prefix (a bump mints **fresh empty** volumes), and inventories the PVCs that must survive. On uninstall+install it notes the accurate picture: with `keepPvcOnDelete=true` the router's `ensurePersistentVolumeClaim()` finds existing claims and reuses the **same** volumes, so nothing is re-provisioned — the VAST quota-collision hazard only appears if a PVC is actually deleted first (`keepPvcOnDelete=false`, a manual `kubectl delete pvc`, or a `storage.nameVersion` bump; the VAST quota name `csi:<ns>:<pvc>:pvc-<uid>` is truncated at 64 chars, cutting off the UID, so a re-create reuses the same quota name). `--out DIR` records a manifest (namespace/name/UID/volumeName/phase); `--verify DIR` afterwards proves every PVC kept the **same UID and volumeName** — the check that catches a silent re-bind to an empty volume. The dump is a **record, not a backup**: PVs here use `reclaimPolicy: Delete`, so deleting a PVC destroys its data.
- `scripts/cleanup-dsh-web-helm-stale-quotas.sh` — VAST quota cleanup (dry-run default)

## Known follow-ups

- dsh is a fast-moving developer preview (`0.1.x`): session-store paths (admin "clear sessions" job) and the remote-MCP config schema should be re-verified per dsh version.
- With SSO enabled, host registration at the platform auth layer remains an out-of-band admin step.
