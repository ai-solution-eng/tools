# Example values files (shareable · secret-free)

This folder holds **sanitized, paste-ready example values files** for the
Model Manager chart (`model-manager`). It is hardlinked into the public delivery tree
(`pcai-solutions/tools/model-manager/`), so everything here must be
safe to publish:

- **No secrets.** Credentials are role-named placeholders (`<MINIO_ACCESS_KEY>`,
  `<MINIO_PASSWORD>`); usernames/namespaces are `<USERNAME>`,
  `project-user-<USERNAME>`. Site endpoints/domains and internal hostnames are
  NOT published here — the proxy targets are placeholders
  (`proxy.corp.example`), and the proxied-corporate-site example describes a
  generic corporate egress proxy, not a named HPE cluster.
- **Real per-site values live in `helm/local/`** (repo-only: gitignored via
  `helm*/local/*`, hardlink-ignored via `helm*/local`, never packaged via
  `helm/.helmignore`). See `helm/local/README.md` in the source repo for that
  convention. Never copy credentials from `helm/local/` into this folder.

## Placeholder convention

Every value **you** must replace is wrapped in angle brackets and named for
its role — `<MINIO_PASSWORD>`, `<EMBEDDER_API_KEY>`, `<USERNAME>`. The one
exception is `${DOMAIN_NAME}`: PCAI substitutes it before rendering, so leave
it as-is. Lowercase `<tokens>` inside comments are illustrative patterns, not
values.

## Files

| File | Target | Highlights |
|---|---|---|
| [`values.g2.yaml`](values.g2.yaml) | Proxied corporate PCAI site (placeholder addresses) | `proxy:` dict wired (corporate egress proxy + `noProxy`), PVC + MinIO (`mlis-models` bucket), `project-user-*` namespaces, `downloader.hf.verifyTls: false` (MITM proxy with an untrusted cert — secure default is verify-on), `pcai.enabled: true` explicit, and the `oidc:` issuer/JWKS pair the admin deletion gate verifies tokens against. |
| [`values.hosted-trial.yaml`](values.hosted-trial.yaml) | Customer-hosted PCAI (hosted trial) | `${DOMAIN_NAME}` placeholders for EZUA ingress, direct egress (`proxy: {}`), storage backend choice, the `oidc:` issuer/JWKS pair for admin-gate token verification, Kyverno gate called out in the header. |

## Using a file on PCAI

1. **Import the chart once** into PCAI (the packaged chart, e.g.
   `model-manager-2.1.2.tar.gz`). PCAI users never run `helm install` /
   `kubectl apply` — deployment is values-only after the import.
2. **Open the chart's Helm Values editor** in PCAI and paste the whole file
   (both files are *full values* documents — they stand alone and do not
   depend on the chart defaults being merged first, though merging works too).
3. **Adjust the `# SITE:` lines** — namespace, usernames, S3 endpoint/bucket
   and keys, MLIS/AIOLI endpoint if it differs.
4. **Apply.** PCAI resolves `${DOMAIN_NAME}` before rendering; leave those
   placeholders untouched.

On SE G2, apply `values.g2.yaml` as-is after filling the `# SITE:` lines. On a
hosted trial, read the hosted-trial prerequisite in
[documentation/DEPLOYMENT.md §1.2](../../documentation/DEPLOYMENT.md#12-cluster-objects-and-patches)
first — the chart's downloader Jobs must be admitted by the
platform-wide `protect-models-pvc` Kyverno policy (the customer admin may need
to apply the job-controller patch), and `kyverno.enabled` must stay `true`.

## Sanity-checking a render (operators)

Operators with `helm` available can eyeball the render before touching PCAI:

```bash
helm lint helm
helm template helm -f helm/values-examples/values.g2.yaml
helm template helm -f helm/values-examples/values.hosted-trial.yaml
```

`${DOMAIN_NAME}` stays a literal string in the render (PCAI substitutes it at
apply time); on a non-PCAI cluster, pass `--set ezua.domainName=<real-domain>`
for the check.
