#!/usr/bin/env bash
# Unified formatter for PCAI repos.
#
# Runs ruff format / ruff check --fix / mypy on the Python code next to it:
#
#   * linked at <repo>/src/<pkg>/formatter.sh  -> lints that package (and, when
#     present, <repo>/tests/)
#   * linked at <repo>/tests/formatter.sh      -> lints tests/ only
#   * run from a repo root (hardlinked copy)   -> lints all src/* packages +
#     tests/ (legacy behaviour)
#
# Config (ruff.toml / mypy.ini) is located by walking up to the repo root, so
# the script works from any of the above locations.
#
# Usage: ./formatter.sh [<target-repo-root>]
#   <target-repo-root>  optional explicit repo root (repo-wide run regardless
#                       of where the script lives).
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------------------------------------------------------------------
# Locate the repo root (contains ruff.toml) by walking up from this script.
# ---------------------------------------------------------------------------
REPO=""
cur="$SCRIPT_DIR"
while [[ "$cur" != "/" && -z "$REPO" ]]; do
  if [[ -f "$cur/ruff.toml" ]]; then
    REPO="$cur"
  fi
  cur="$(dirname "$cur")"
done

if [[ -z "$REPO" ]]; then
  echo "SKIP  $SCRIPT_DIR (no ruff.toml found; refusing to reformat shared utils with defaults)"
  exit 0
fi
if [[ ! -f "$REPO/mypy.ini" ]]; then
  echo "SKIP  $REPO (mypy.ini not found next to ruff.toml)"
  exit 0
fi

# ---------------------------------------------------------------------------
# Decide what to lint based on where this script lives (or the explicit arg).
# ---------------------------------------------------------------------------
mode="pkg"  # default: lint this package (+ tests when present)
if [[ $# -ge 1 ]]; then
  mode="repo"
  REPO="$(cd "$1" && pwd)"
elif [[ "$(basename "$SCRIPT_DIR")" == "tests" ]]; then
  mode="tests"
elif [[ "$(basename "$(dirname "$SCRIPT_DIR")")" == "src" ]]; then
  mode="pkg"
elif [[ -f "$SCRIPT_DIR/ruff.toml" && -d "$SCRIPT_DIR/src" ]]; then
  mode="repo"
fi

targets=()
add_target() { # add_target <dir>  — only if it contains Python files
  if find "$1" -maxdepth 3 -name "*.py" -print -quit 2>/dev/null | grep -q .; then
    targets+=("${1%/}")
  else
    echo "SKIP  $1 (no Python files)"
  fi
}

case "$mode" in
  repo)
    shopt -s nullglob
    packages=("$REPO"/src/*/)
    shopt -u nullglob
    for pkg in "${packages[@]}"; do
      base="$(basename "$pkg")"
      case "$base" in
        .mypy_cache | __pycache__ | build) continue ;;
      esac
      add_target "${pkg%/}"
    done
    if [[ -d "$REPO/tests" ]]; then
      add_target "$REPO/tests"
    fi
    ;;
  tests)
    add_target "$SCRIPT_DIR"
    ;;
  pkg)
    add_target "$SCRIPT_DIR"
    if [[ -d "$REPO/tests" ]]; then
      add_target "$REPO/tests"
    fi
    ;;
esac

if [[ ${#targets[@]} -eq 0 ]]; then
  echo "No Python files found to lint." >&2
  exit 1
fi

failed=0
for t in "${targets[@]}"; do
  echo "== $t =="
  ruff format "$t" || failed=1
  ruff check --fix "$t" || failed=1
  echo ''
  mypy --config-file "$REPO/mypy.ini" "$t" || failed=1
  echo ''
done

if [[ $failed -ne 0 ]]; then
  echo "FORMATTER: errors found (see above)" >&2
  exit 1
fi
echo "FORMATTER: all clean"